# تطبيق العميل – حجز سيارات الأجرة (Expo / React Native)

## التشغيل
1. ثبّت Node.js ثم نفّذ داخل المجلد:
   npm install
   npx expo install --fix      # يضبط نسخ الحزم المتوافقة مع Expo
2. ضع مفتاح Google Maps في app.json (android.config.googleMaps.apiKey).
3. للتجربة على الجوال: npx expo start ثم افتح التطبيق عبر Expo Go.

## بناء APK
   npm install -g eas-cli
   eas login
   eas build -p android --profile preview      # ينتج ملف APK للتجربة

## ما هو حقيقي وما هو مؤقت
- حقيقي: الشاشات والتدفق، دبوسا الخريطة الأحمر والأزرق، موقع المستخدم، البحث عن العنوان، معادلات الأسعار (src/pricing.js) ورسوم المطار.
- مؤقت: المسافة والوقت تقدير مستقيم × 1.3 بسرعة 30 كم/س (src/pricing.js: estimateTrip) → استبدله بـ Google Routes/Directions.
- مؤقت: البحث عن سائق، بيانات السائق، المراسلة، الإلغاء، التقييم (src/screens/Flow.js) → تحتاج خادماً وقاعدة بيانات.
- الرحلة "من/إلى المطار" مفتاح يدوي الآن؛ يمكن اكتشافها تلقائياً بإحداثيات المطارات.
- الوقت يُحسب بالتناسب مع المدة (30 دقيقة = نصف سعر الساعة).
