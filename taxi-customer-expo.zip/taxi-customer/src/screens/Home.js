import React, { useEffect, useRef } from 'react';
import { View, Text, Pressable } from 'react-native';
import MapView from 'react-native-maps';
import { MaterialIcons } from '@expo/vector-icons';
import { C, S, Row } from '../ui';
import { myLocation, addressOf } from '../geo';
function Opt({ icon, color, t, sub, bg, border, onPress }) {
  return (
    <Pressable accessibilityRole="button" onPress={onPress} style={{ minHeight: 68, borderRadius: 16, padding: 12, backgroundColor: bg, borderWidth: 2, borderColor: border }}>
      <Row><MaterialIcons name={icon} size={28} color={color} /><View style={{ flex: 1 }}><Text style={[S.txt, { fontWeight: '700', fontSize: 17 }]}>{t}</Text><Text style={S.mute}>{sub}</Text></View></Row>
    </Pressable>
  );
}
export default function Home({ go, setTrip }) {
  const ref = useRef(null);
  useEffect(() => { myLocation().then((me) => me && ref.current?.animateToRegion({ latitude: me.lat, longitude: me.lng, latitudeDelta: 0.01, longitudeDelta: 0.01 })); }, []);
  const useMine = async () => {
    const me = await myLocation();
    if (!me) return go('pickupMap');
    setTrip((t) => ({ ...t, pickup: { ...me, address: 'موقعي الحالي' } }));
    addressOf(me.lat, me.lng).then((a) => setTrip((t) => ({ ...t, pickup: { ...me, address: a } })));
    go('search');
  };
  return (
    <View style={{ flex: 1 }}>
      <MapView ref={ref} style={{ flex: 1 }} showsUserLocation />
      <View style={S.sheet}>
        <Text style={[S.title, { fontSize: 24 }]}>أين تريد الذهاب؟</Text>
        <Opt icon="my-location" color={C.ink} t="ابدأ الرحلة من موقعي الحالي" sub="الالتقاط من مكانك الآن" bg={C.amber} border={C.amber} onPress={useMine} />
        <Opt icon="location-on" color={C.red} t="حدد نقطة الالتقاط على الخريطة" sub="حرّك الخريطة والدبوس ثابت في الوسط" bg="#fff" border={C.ink} onPress={() => go('pickupMap')} />
        <Opt icon="location-on" color={C.blue} t="حدد وجهتك" sub="اكتبها أو اخترها بالدبوس الأزرق" bg="#fff" border={C.blue} onPress={() => go('search')} />
      </View>
    </View>
  );
}
