import React, { useEffect, useState } from 'react';
import { View, Text, Image, Pressable, TextInput, Modal, Linking, ScrollView, ActivityIndicator } from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import { C, S, Btn, Back, Row, usd } from '../ui';
import { CARS, fare } from '../pricing';
// بيانات السائق تأتي لاحقاً من الخادم. هذه قيم مؤقتة.
export const DRIVER = { name: '[الاسم] [الشهرة]', plate: '[رقم اللوحة]', rating: 96, color: 'أبيض', phone: '+000000000' };

export function CancelSheet({ visible, onClose, onConfirm }) {
  const reasons = ['غيّرت رأيي', 'السائق تأخر', 'طلبت بالخطأ', 'سبب آخر'];
  const [sel, setSel] = useState(null);
  return (
    <Modal transparent animationType="slide" visible={visible} onRequestClose={onClose}>
      <View style={{ flex: 1, backgroundColor: 'rgba(16,24,32,.55)', justifyContent: 'flex-end' }}>
        <View style={[S.sheet, { position: 'relative' }]}>
          <Text style={S.title}>إلغاء الرحلة؟</Text>
          <Text style={S.mute}>اختر سبب الإلغاء. [سياسة رسوم الإلغاء]</Text>
          {reasons.map((r) => (
            <Pressable key={r} accessibilityRole="radio" accessibilityState={{ selected: sel === r }} onPress={() => setSel(r)}
              style={{ height: 52, borderRadius: 14, borderWidth: 2, borderColor: sel === r ? C.ink : C.line, paddingHorizontal: 14, justifyContent: 'center', backgroundColor: sel === r ? '#F2F4F5' : '#fff' }}>
              <Row><View style={{ width: 22, height: 22, borderRadius: 11, borderWidth: sel === r ? 6 : 2, borderColor: sel === r ? C.ink : '#8A96A0' }} /><Text style={S.txt}>{r}</Text></Row>
            </Pressable>))}
          <Btn kind="danger" label="تأكيد الإلغاء" disabled={!sel} onPress={() => { onConfirm(sel); setSel(null); }} />
          <Btn kind="outline" label="الاحتفاظ بالرحلة" onPress={onClose} />
        </View>
      </View>
    </Modal>
  );
}

export function Searching({ go }) {
  useEffect(() => { const t = setTimeout(() => go('driver'), 3500); return () => clearTimeout(t); }, []); // محاكاة: استبدلها بانتظار قبول سائق من الخادم
  return (
    <View style={[S.screen, { alignItems: 'center', justifyContent: 'center', gap: 20 }]}>
      <ActivityIndicator size="large" color={C.red} />
      <Text style={S.title}>جارٍ البحث عن سائق قريب…</Text>
      <View style={{ width: '100%' }}><Btn kind="dangerOutline" label="إلغاء الطلب" onPress={() => go('home')} /></View>
    </View>
  );
}

export function Driver({ trip, go, onCancel }) {
  const car = CARS.find((c) => c.id === trip.car);
  return (
    <View style={S.screen}>
      <Text style={[S.title, { textAlign: 'center' }]}>تم تأكيد الحجز · السائق في الطريق إليك</Text>
      <View style={S.card}>
        <Row style={{ gap: 14 }}>
          <View style={{ width: 68, height: 68, borderRadius: 34, backgroundColor: '#D5DBDF', alignItems: 'center', justifyContent: 'center' }}><MaterialIcons name="person" size={44} color="#8A96A0" /></View>
          <View style={{ flex: 1 }}><Text style={S.mute}>سائقك</Text><Text style={[S.title, { fontSize: 21 }]}>{DRIVER.name}</Text></View>
          <View style={{ alignItems: 'center' }}><Row style={{ gap: 4 }}><MaterialIcons name="star" size={22} color={C.amber} /><Text style={[S.title, { fontSize: 20 }]}>{DRIVER.rating}%</Text></Row><Text style={S.mute}>تقييم الركاب</Text></View>
        </Row>
        <View style={{ height: 8, borderRadius: 4, backgroundColor: C.line }}><View style={{ width: `${DRIVER.rating}%`, height: 8, borderRadius: 4, backgroundColor: C.amber }} /></View>
      </View>
      <View style={[S.card, { backgroundColor: '#F2F4F5' }]}>
        <Row><View style={{ flex: 1 }}><Text style={[S.title, { fontSize: 19 }]}>{car.name}</Text><Text style={S.txt}>اللون: {DRIVER.color}</Text></View><Image source={car.img} style={{ width: 132, height: 92, borderRadius: 12 }} resizeMode="cover" /></Row>
      </View>
      <View style={{ borderWidth: 3, borderColor: C.ink, borderRadius: 14, padding: 12 }}><Row><Text style={[S.mute, { flex: 1 }]}>رقم اللوحة</Text><Text style={[S.title, { fontSize: 26 }]}>{DRIVER.plate}</Text></Row></View>
      <Row style={{ gap: 10 }}>
        <View style={{ flex: 1 }}><Btn label="اتصال" onPress={() => Linking.openURL('tel:' + DRIVER.phone)} /></View>
        <View style={{ flex: 1 }}><Btn kind="outline" label="رسالة" onPress={() => go('chat')} /></View>
      </Row>
      <Btn label="بدء الرحلة (محاكاة)" kind="outline" onPress={() => go('inTrip')} />
      <Pressable onPress={onCancel} style={{ padding: 8 }}><Text style={{ color: C.red, fontWeight: '700', textAlign: 'center', fontSize: 15 }}>إلغاء الرحلة</Text></Pressable>
    </View>
  );
}

export function Chat({ go }) {
  const [msgs, setMsgs] = useState([{ me: false, t: 'أنا في الطريق إليك.' }]);
  const [txt, setTxt] = useState('');
  const send = (t) => { if (t.trim()) { setMsgs((m) => [...m, { me: true, t }]); setTxt(''); } }; // الإرسال الفعلي عبر خادم المراسلة لاحقاً
  return (
    <View style={[S.screen, { backgroundColor: '#fff', paddingBottom: 24 }]}>
      <Row><Back onPress={() => go('driver')} /><View style={{ flex: 1 }}><Text style={[S.title, { fontSize: 17 }]}>{DRIVER.name}</Text><Text style={S.mute}>{DRIVER.plate}</Text></View>
        <Pressable accessibilityLabel="اتصال" onPress={() => Linking.openURL('tel:' + DRIVER.phone)} style={{ width: 48, height: 48, borderRadius: 24, backgroundColor: C.amber, alignItems: 'center', justifyContent: 'center' }}><MaterialIcons name="call" size={24} color={C.ink} /></Pressable></Row>
      <ScrollView style={{ flex: 1, backgroundColor: '#F2F4F5', borderRadius: 16 }} contentContainerStyle={{ padding: 12, gap: 8 }}>
        {msgs.map((m, i) => <View key={i} style={{ alignSelf: m.me ? 'flex-end' : 'flex-start', maxWidth: '80%', backgroundColor: m.me ? C.amber : '#fff', borderRadius: 16, padding: 10 }}><Text style={S.txt}>{m.t}</Text></View>)}
      </ScrollView>
      <Row style={{ flexWrap: 'wrap' }}>{['أنا هنا', 'أين أنت؟', 'أحتاج دقيقتين'].map((q) => <Pressable key={q} onPress={() => send(q)} style={{ height: 40, paddingHorizontal: 14, borderRadius: 20, borderWidth: 1.5, borderColor: C.ink, justifyContent: 'center' }}><Text>{q}</Text></Pressable>)}</Row>
      <Row><TextInput accessibilityLabel="رسالة" placeholder="اكتب رسالة للسائق" value={txt} onChangeText={setTxt} style={{ flex: 1, height: 48, borderRadius: 24, backgroundColor: '#F2F4F5', paddingHorizontal: 16, textAlign: 'right', fontSize: 16 }} />
        <Pressable accessibilityLabel="إرسال" onPress={() => send(txt)} style={{ width: 48, height: 48, borderRadius: 24, backgroundColor: C.ink, alignItems: 'center', justifyContent: 'center' }}><MaterialIcons name="send" size={22} color="#fff" /></Pressable></Row>
    </View>
  );
}

export function InTrip({ trip, go, onCancel }) {
  return (
    <View style={[S.screen, { justifyContent: 'flex-end', paddingBottom: 28 }]}>
      <View style={S.card}><Text style={S.title}>الرحلة جارية</Text><Text style={S.mute}>الوجهة: {trip.dest.address}</Text><Text style={S.mute}>الوصول بعد حوالي {trip.minutes} دقيقة</Text></View>
      <Btn label="تأكيد الوصول وإنهاء الرحلة" onPress={() => go('rating')} />
      <Pressable onPress={onCancel} style={{ padding: 8 }}><Text style={{ color: C.red, fontWeight: '700', textAlign: 'center' }}>إلغاء الرحلة</Text></Pressable>
    </View>
  );
}

function Stars({ value, onChange }) {
  return <Row style={{ justifyContent: 'center', gap: 2 }}>{[1, 2, 3, 4, 5].map((n) => <Pressable key={n} accessibilityLabel={`${n} من 5`} onPress={() => onChange(n)} style={{ width: 44, height: 44, alignItems: 'center', justifyContent: 'center' }}><MaterialIcons name={n <= value ? 'star' : 'star-border'} size={36} color={n <= value ? C.amber : '#8A96A0'} /></Pressable>)}</Row>;
}
export function Rating({ trip, go }) {
  const [r, setR] = useState({ behavior: 0, clean: 0, knowledge: 0 });
  const [note, setNote] = useState('');
  const car = CARS.find((c) => c.id === trip.car), f = fare(car, trip.km, trip.minutes, trip.airport);
  const rows = [['behavior', 'السلوك'], ['clean', 'نظافة السيارة'], ['knowledge', 'معرفته بالأماكن']];
  return (
    <ScrollView style={{ backgroundColor: '#fff' }} contentContainerStyle={[S.screen, { backgroundColor: '#fff', paddingBottom: 28 }]}>
      <Row><View style={{ flex: 1 }}><Text style={S.title}>وصلت بسلام</Text><Text style={S.mute}>قيّم رحلتك مع {DRIVER.name}</Text></View><Text style={[S.title, { fontSize: 20 }]}>{usd(f.total)}</Text></Row>
      {rows.map(([k, t]) => <View key={k} style={[S.card, { backgroundColor: '#F2F4F5' }]}><Text style={[S.txt, { fontWeight: '700' }]}>{t}</Text><Stars value={r[k]} onChange={(n) => setR({ ...r, [k]: n })} /></View>)}
      <Text style={[S.txt, { fontWeight: '700' }]}>اقتراحك (اختياري)</Text>
      <TextInput accessibilityLabel="اقتراحك" placeholder="اكتب اقتراحك هنا" value={note} onChangeText={setNote} multiline style={{ height: 96, borderWidth: 2, borderColor: '#D5DBDF', borderRadius: 14, padding: 12, textAlign: 'right', textAlignVertical: 'top', fontSize: 16 }} />
      <Btn label="إرسال التقييم" onPress={() => { /* أرسل r و note إلى الخادم */ go('home', true); }} />
    </ScrollView>
  );
}
