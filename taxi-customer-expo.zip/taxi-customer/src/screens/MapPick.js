import React, { useEffect, useRef, useState } from 'react';
import { View, Text } from 'react-native';
import MapView from 'react-native-maps';
import { MaterialIcons } from '@expo/vector-icons';
import { C, S, Btn, Back, Row } from '../ui';
import { addressOf, myLocation } from '../geo';
// الدبوس ثابت في وسط الشاشة، وتتحرك الخريطة تحته. mode: 'pickup' (أحمر) أو 'dest' (أزرق)
export default function MapPick({ mode, start, onConfirm, onBack }) {
  const color = mode === 'pickup' ? C.red : C.blue;
  const ref = useRef(null);
  const [center, setCenter] = useState(start || { lat: 24.7136, lng: 46.6753 });
  const [address, setAddress] = useState('...');
  useEffect(() => { addressOf(center.lat, center.lng).then(setAddress); }, [center]);
  const recenter = async () => {
    const me = await myLocation();
    if (me) ref.current?.animateToRegion({ latitude: me.lat, longitude: me.lng, latitudeDelta: 0.01, longitudeDelta: 0.01 });
  };
  return (
    <View style={{ flex: 1 }}>
      <MapView ref={ref} style={{ flex: 1 }} showsUserLocation
        initialRegion={{ latitude: center.lat, longitude: center.lng, latitudeDelta: 0.01, longitudeDelta: 0.01 }}
        onRegionChangeComplete={(r) => setCenter({ lat: r.latitude, lng: r.longitude })} />
      <View pointerEvents="none" style={{ position: 'absolute', top: '50%', left: '50%', marginLeft: -26, marginTop: -52 }}>
        <MaterialIcons name="location-on" size={52} color={color} />
      </View>
      <View style={{ position: 'absolute', top: 56, right: 16 }}><Back onPress={onBack} /></View>
      <View style={{ position: 'absolute', top: 64, left: 0, right: 0, alignItems: 'center' }} pointerEvents="none">
        <Text style={{ backgroundColor: C.ink, color: '#fff', paddingHorizontal: 14, paddingVertical: 8, borderRadius: 20, overflow: 'hidden' }}>
          {mode === 'pickup' ? 'حرّك الخريطة لتحديد نقطة الالتقاط' : 'حرّك الخريطة لتحديد وجهتك'}
        </Text>
      </View>
      <View style={S.sheet}>
        <Text style={S.mute}>{mode === 'pickup' ? 'نقطة الالتقاط' : 'الوجهة'}</Text>
        <Row><View style={{ width: 12, height: 12, borderRadius: mode === 'pickup' ? 6 : 0, backgroundColor: color }} /><Text style={[S.title, { flex: 1, fontSize: 18 }]} numberOfLines={2}>{address}</Text></Row>
        {mode === 'pickup' && <Btn kind="outline" label="التقاطي من موقعي الحالي" onPress={recenter} />}
        <Btn kind={mode === 'pickup' ? 'primary' : 'blue'} label={mode === 'pickup' ? 'تأكيد نقطة الالتقاط' : 'تأكيد الوجهة'} onPress={() => onConfirm({ ...center, address })} />
      </View>
    </View>
  );
}
