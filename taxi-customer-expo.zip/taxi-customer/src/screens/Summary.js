import React from 'react';
import { View, Text } from 'react-native';
import { C, S, Btn, Back, Row, usd } from '../ui';
import { CARS, fare, AIRPORT_FEE } from '../pricing';
function Line({ t, sub, v }) {
  return <Row style={{ paddingVertical: 10, borderBottomWidth: 1, borderBottomColor: C.line }}><View style={{ flex: 1 }}><Text style={S.txt}>{t}</Text>{!!sub && <Text style={S.mute}>{sub}</Text>}</View><Text style={[S.txt, { fontWeight: '700' }]}>{v}</Text></Row>;
}
export default function Summary({ trip, go }) {
  const car = CARS.find((c) => c.id === trip.car);
  const f = fare(car, trip.km, trip.minutes, trip.airport);
  return (
    <View style={S.screen}>
      <Row><Back onPress={() => go('vehicles')} /><Text style={S.title}>ملخص الرحلة والسعر</Text></Row>
      <View style={S.card}>
        <Row><View style={{ width: 10, height: 10, borderRadius: 5, backgroundColor: C.red }} /><Text style={[S.txt, { flex: 1 }]} numberOfLines={1}>{trip.pickup.address}</Text></Row>
        <Row><View style={{ width: 10, height: 10, backgroundColor: C.blue }} /><Text style={[S.txt, { flex: 1 }]} numberOfLines={1}>{trip.dest.address}</Text></Row>
        <Text style={S.mute}>{trip.km} كم · {trip.minutes} دقيقة تقريباً · {car.name}</Text>
      </View>
      <View style={S.card}>
        <Line t="رسم ثابت" v={usd(f.base)} />
        <Line t="المسافة" sub={`${trip.km} كم × $${car.perKm}`} v={usd(f.distance)} />
        <Line t="الوقت" sub={`${(trip.minutes / 60).toFixed(2)} ساعة × $${car.perHour}`} v={usd(f.time)} />
        {trip.airport && <Line t="موقف ورسوم مطار" sub={`تُضاف تلقائياً`} v={usd(AIRPORT_FEE)} />}
        <Row style={{ paddingTop: 8 }}><Text style={[S.title, { flex: 1, fontSize: 17 }]}>الإجمالي (دولار أمريكي)</Text><Text style={[S.title, { fontSize: 24 }]}>{usd(f.total)}</Text></Row>
      </View>
      <View style={{ flex: 1 }} />
      <View style={{ paddingBottom: 20 }}><Btn label="اطلب السيارة" onPress={() => go('searching')} /></View>
    </View>
  );
}
