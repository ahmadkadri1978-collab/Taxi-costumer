import React, { useEffect, useState } from 'react';
import { View, Text, TextInput, Pressable, FlatList } from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import { C, S, Back, Row } from '../ui';
import { search, myLocation, addressOf } from '../geo';
export default function Search({ trip, setTrip, go }) {
  const [q, setQ] = useState('');
  const [res, setRes] = useState([]);
  useEffect(() => {
    if (trip.pickup) return;
    myLocation().then(async (me) => me && setTrip((t) => ({ ...t, pickup: { ...me, address: 'موقعي الحالي' } })));
  }, []);
  const pick = (p) => { setTrip((t) => ({ ...t, dest: p })); go('vehicles'); };
  return (
    <View style={[S.screen, { backgroundColor: '#fff' }]}>
      <Row><Back onPress={() => go('home')} /><Text style={S.title}>إلى أين تريد الذهاب؟</Text></Row>
      <View style={{ backgroundColor: '#F2F4F5', borderRadius: 16, paddingHorizontal: 14 }}>
        <Row style={{ height: 44 }}><View style={{ width: 10, height: 10, borderRadius: 5, backgroundColor: C.red }} /><Text style={[S.mute, { flex: 1 }]} numberOfLines={1}>{trip.pickup?.address || 'نقطة الالتقاط'}</Text></Row>
        <Row style={{ height: 48 }}><View style={{ width: 10, height: 10, backgroundColor: C.blue }} />
          <TextInput accessibilityLabel="الوجهة" placeholder="اكتب اسم المكان أو العنوان" value={q} onChangeText={setQ} returnKeyType="search"
            onSubmitEditing={async () => setRes(await search(q))} style={{ flex: 1, fontSize: 17, textAlign: 'right', borderBottomWidth: 2, borderBottomColor: C.blue }} /></Row>
      </View>
      <Pressable onPress={() => go('destMap')} style={{ height: 56, borderRadius: 16, borderWidth: 2, borderColor: C.blue, paddingHorizontal: 14, justifyContent: 'center' }}>
        <Row><MaterialIcons name="location-on" size={28} color={C.blue} /><Text style={{ fontSize: 17, fontWeight: '700', color: C.blue }}>تحديد الوجهة على الخريطة</Text></Row>
      </Pressable>
      <FlatList data={res} keyExtractor={(_, i) => String(i)} renderItem={({ item }) => (
        <Pressable onPress={() => pick(item)} style={{ height: 60, justifyContent: 'center', borderBottomWidth: 1, borderBottomColor: C.line }}><Text style={S.txt}>{item.address}</Text></Pressable>)} />
    </View>
  );
}
