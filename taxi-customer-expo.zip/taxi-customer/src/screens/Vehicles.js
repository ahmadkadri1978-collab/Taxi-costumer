import React, { useMemo, useState } from 'react';
import { View, Text, Image, Pressable, Switch, ScrollView } from 'react-native';
import { C, S, Btn, Back, Row, usd } from '../ui';
import { CARS, fare, estimateTrip, AIRPORT_FEE } from '../pricing';
export default function Vehicles({ trip, setTrip, go }) {
  const info = useMemo(() => estimateTrip(trip.pickup, trip.dest), [trip.pickup, trip.dest]);
  const [car, setCar] = useState(trip.car || CARS[0].id);
  const [airport, setAirport] = useState(!!trip.airport);
  const next = () => { setTrip((t) => ({ ...t, car, airport, ...info })); go('summary'); };
  return (
    <View style={S.screen}>
      <Row><Back onPress={() => go('search')} /><Text style={S.title}>اختر سيارتك</Text></Row>
      <View style={S.card}>
        <Row style={{ gap: 8 }}>
          <View style={{ flex: 1, backgroundColor: '#F2F4F5', borderRadius: 12, padding: 8 }}><Text style={S.mute}>المسافة</Text><Text style={[S.txt, { fontWeight: '700' }]}>{info.km} كم</Text></View>
          <View style={{ flex: 1, backgroundColor: '#F2F4F5', borderRadius: 12, padding: 8 }}><Text style={S.mute}>الوقت التقريبي</Text><Text style={[S.txt, { fontWeight: '700' }]}>{info.minutes} دقيقة</Text></View>
        </Row>
        <Row><Text style={[S.txt, { flex: 1 }]}>الرحلة من/إلى المطار (+{usd(AIRPORT_FEE)})</Text><Switch value={airport} onValueChange={setAirport} /></Row>
      </View>
      <ScrollView contentContainerStyle={{ gap: 10 }}>
        {CARS.map((c) => {
          const f = fare(c, info.km, info.minutes, airport), sel = c.id === car;
          return (
            <Pressable key={c.id} accessibilityRole="button" onPress={() => setCar(c.id)} style={{ borderRadius: 18, padding: 10, borderWidth: 2, borderColor: sel ? C.amber : '#fff', backgroundColor: sel ? '#FFF6DB' : '#fff' }}>
              <Row>
                <View style={{ flex: 1, gap: 4 }}>
                  <Row><Text style={[S.title, { fontSize: 19, flex: 1 }]}>{c.name}</Text><Text style={[S.title, { fontSize: 19 }]}>{usd(f.total)}</Text></Row>
                  <Text style={[S.mute, { fontSize: 12.5 }]}>${c.perKm}/كم + ${c.base} ثابتة + ${c.perHour}/ساعة</Text>
                  <Text style={S.txt}>{c.seats} ركاب · {c.bags} حقائب</Text>
                </View>
                <Image source={c.img} style={{ width: 112, height: 90, borderRadius: 12 }} resizeMode="cover" />
              </Row>
            </Pressable>
          );
        })}
      </ScrollView>
      <View style={{ paddingBottom: 20 }}><Btn label="متابعة" onPress={next} /></View>
    </View>
  );
}
