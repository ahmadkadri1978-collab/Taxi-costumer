// معادلات التسعير (دولار أمريكي): الإجمالي = رسم ثابت + كم × سعر الكم + ساعات × سعر الساعة (+ المطار)
export const AIRPORT_FEE = 10;
export const CARS = [
  { id: 'sedan', name: 'سيدان', img: require('../assets/sedan.jpg'), seats: '4', bags: '3', perKm: 1, base: 3, perHour: 3 },
  { id: 'awd', name: 'دفع رباعي', img: require('../assets/awd.jpg'), seats: '4-5', bags: '4-5', perKm: 1.2, base: 4, perHour: 4 },
  { id: 'mpv', name: 'كرفان عائلي', img: require('../assets/mpv.jpg'), seats: '6-7', bags: '5-6', perKm: 1.4, base: 4, perHour: 4 },
  { id: 'h1', name: 'فان H1', img: require('../assets/h1.jpg'), seats: '7-9', bags: '6-8', perKm: 1.6, base: 5, perHour: 6 },
];
const r2 = (n) => Math.round(n * 100) / 100;
export function fare(car, km, minutes, airport) {
  const hours = minutes / 60; // الوقت يُحسب بالتناسب مع المدة (افتراض)
  const base = car.base, distance = r2(km * car.perKm), time = r2(hours * car.perHour);
  const air = airport ? AIRPORT_FEE : 0;
  return { base, distance, time, airport: air, total: r2(base + distance + time + air) };
}
// تقدير مؤقت: مسافة مستقيمة × 1.3 وسرعة 30 كم/س. استبدله بخدمة مسارات حقيقية (Google Directions/Routes).
export function estimateTrip(a, b) {
  const R = 6371, d2r = Math.PI / 180;
  const dLat = (b.lat - a.lat) * d2r, dLng = (b.lng - a.lng) * d2r;
  const h = Math.sin(dLat / 2) ** 2 + Math.cos(a.lat * d2r) * Math.cos(b.lat * d2r) * Math.sin(dLng / 2) ** 2;
  const km = r2(2 * R * Math.asin(Math.sqrt(h)) * 1.3);
  return { km, minutes: Math.max(1, Math.round((km / 30) * 60)) };
}
