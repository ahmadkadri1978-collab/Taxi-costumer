import React from 'react';
import { I18nManager, Pressable, Text, View, StyleSheet } from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
export const C = { ink: '#101820', amber: '#F2A900', red: '#D93025', blue: '#1A66D9', bg: '#E9EDEF', mute: '#4A5763', line: '#E1E6E9' };
export const ROW = I18nManager.isRTL ? 'row' : 'row-reverse'; // الترتيب من اليمين لليسار دائماً
export const S = StyleSheet.create({
  sheet: { position: 'absolute', left: 0, right: 0, bottom: 0, backgroundColor: '#fff', borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 16, paddingBottom: 28, gap: 12 },
  title: { fontSize: 22, fontWeight: '700', color: C.ink, textAlign: 'right' },
  mute: { fontSize: 14, color: C.mute, textAlign: 'right' },
  txt: { fontSize: 16, color: C.ink, textAlign: 'right' },
  screen: { flex: 1, backgroundColor: C.bg, paddingTop: 56, paddingHorizontal: 16, gap: 12 },
  card: { backgroundColor: '#fff', borderRadius: 18, padding: 14, gap: 8 },
});
export function Btn({ label, onPress, kind = 'primary', disabled }) {
  const k = { primary: [C.amber, C.ink], danger: [C.red, '#fff'], blue: [C.blue, '#fff'], outline: ['#fff', C.ink], dangerOutline: ['#fff', C.red] }[kind];
  const border = kind === 'outline' ? C.ink : kind === 'dangerOutline' ? C.red : 'transparent';
  return (
    <Pressable accessibilityRole="button" onPress={onPress} disabled={disabled}
      style={{ height: 56, borderRadius: 16, backgroundColor: k[0], borderWidth: 2, borderColor: border, alignItems: 'center', justifyContent: 'center', opacity: disabled ? 0.5 : 1 }}>
      <Text style={{ fontSize: 18, fontWeight: '700', color: k[1] }}>{label}</Text>
    </Pressable>
  );
}
export function Back({ onPress }) {
  return (
    <Pressable accessibilityLabel="رجوع" onPress={onPress} style={{ width: 44, height: 44, borderRadius: 22, backgroundColor: '#fff', alignItems: 'center', justifyContent: 'center' }}>
      <MaterialIcons name={I18nManager.isRTL ? 'arrow-forward' : 'arrow-back'} size={22} color={C.ink} />
    </Pressable>
  );
}
export function Row({ children, style }) { return <View style={[{ flexDirection: ROW, alignItems: 'center', gap: 10 }, style]}>{children}</View>; }
export const usd = (n) => '$' + n.toFixed(2);
