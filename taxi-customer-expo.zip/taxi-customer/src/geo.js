import * as Location from 'expo-location';
export async function myLocation() {
  const { status } = await Location.requestForegroundPermissionsAsync();
  if (status !== 'granted') return null;
  const p = await Location.getCurrentPositionAsync({});
  return { lat: p.coords.latitude, lng: p.coords.longitude };
}
export async function addressOf(lat, lng) {
  try {
    const [a] = await Location.reverseGeocodeAsync({ latitude: lat, longitude: lng });
    return [a?.name, a?.street, a?.city].filter(Boolean).join('، ') || 'موقع على الخريطة';
  } catch { return 'موقع على الخريطة'; }
}
export async function search(text) {
  try {
    const list = await Location.geocodeAsync(text);
    return Promise.all(list.slice(0, 5).map(async (r) => ({ lat: r.latitude, lng: r.longitude, address: await addressOf(r.latitude, r.longitude) })));
  } catch { return []; }
}
