import React, { useState } from 'react';
import { View } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import Home from './src/screens/Home';
import MapPick from './src/screens/MapPick';
import Search from './src/screens/Search';
import Vehicles from './src/screens/Vehicles';
import Summary from './src/screens/Summary';
import { Searching, Driver, Chat, InTrip, Rating, CancelSheet } from './src/screens/Flow';
// تنقل بسيط بالحالة. يمكن لاحقاً استبداله بـ React Navigation.
export default function App() {
  const [screen, setScreen] = useState('home');
  const [trip, setTrip] = useState({});
  const [cancel, setCancel] = useState(false);
  const go = (s, reset) => { if (reset) setTrip({}); setScreen(s); };
  const p = { trip, setTrip, go };
  let view;
  switch (screen) {
    case 'pickupMap': view = <MapPick mode="pickup" start={trip.pickup} onBack={() => go('home')} onConfirm={(pt) => { setTrip((t) => ({ ...t, pickup: pt })); go('search'); }} />; break;
    case 'destMap': view = <MapPick mode="dest" start={trip.pickup} onBack={() => go('search')} onConfirm={(pt) => { setTrip((t) => ({ ...t, dest: pt })); go('vehicles'); }} />; break;
    case 'search': view = <Search {...p} />; break;
    case 'vehicles': view = <Vehicles {...p} />; break;
    case 'summary': view = <Summary {...p} />; break;
    case 'searching': view = <Searching {...p} />; break;
    case 'driver': view = <Driver {...p} onCancel={() => setCancel(true)} />; break;
    case 'chat': view = <Chat {...p} />; break;
    case 'inTrip': view = <InTrip {...p} onCancel={() => setCancel(true)} />; break;
    case 'rating': view = <Rating {...p} />; break;
    default: view = <Home {...p} />;
  }
  return (
    <View style={{ flex: 1 }}>
      <StatusBar style="dark" />
      {view}
      <CancelSheet visible={cancel} onClose={() => setCancel(false)} onConfirm={() => { setCancel(false); go('home', true); }} />
    </View>
  );
}
